OK_FORMAT = True

test = {   'name': 'q7',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(near_twenty, 4)) == 'bc8dee77249d35f9baa359d1c2ab36b4'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
