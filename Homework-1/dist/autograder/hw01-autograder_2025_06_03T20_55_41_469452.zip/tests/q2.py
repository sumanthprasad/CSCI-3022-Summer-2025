OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(seconds_in_a_decade) == '7b54be8a1e43a89b0736f55aec0290c5'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
