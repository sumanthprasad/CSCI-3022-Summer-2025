OK_FORMAT = True

test = {   'name': 'q12',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q12_survey) == '556e38165f5e28fc4ea244533e93ff74'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
