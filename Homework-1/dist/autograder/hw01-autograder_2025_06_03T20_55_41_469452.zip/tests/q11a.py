OK_FORMAT = True

test = {   'name': 'q11a',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(int(q11a_answer)) == 'da4fb5c6e93e74d3df8527599fa62642'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
