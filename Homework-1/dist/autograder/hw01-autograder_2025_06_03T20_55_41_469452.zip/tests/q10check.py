OK_FORMAT = True

test = {   'name': 'q10check',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q10_answer, 5)) == '09a27b82e83747cf0b8fbf184c1e477d'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
