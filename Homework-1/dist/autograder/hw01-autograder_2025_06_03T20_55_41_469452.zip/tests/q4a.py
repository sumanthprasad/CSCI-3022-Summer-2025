OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q4a_answer) == '8dde8580c09e4bb356873e195435dd8b'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
