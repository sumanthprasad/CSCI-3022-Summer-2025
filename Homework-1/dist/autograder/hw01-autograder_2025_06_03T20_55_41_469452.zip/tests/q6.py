OK_FORMAT = True

test = {   'name': 'q6',
    'points': [0.5, 0.5, 2],
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(square(1)) == 'c4ca4238a0b923820dcc509a6f75849b'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(square(0)) == 'cfcd208495d565ef66e7dff9f98764da'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(square(2.5)) == 'd62c232f0b3e8fb5da7db1ff61509b94'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
