OK_FORMAT = True

test = {   'name': 'q5b',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(a_percentage, 4)) == 'd5283852114ab721760809b6c091520f'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
