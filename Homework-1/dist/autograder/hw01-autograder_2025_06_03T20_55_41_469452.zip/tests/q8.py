OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(sqrt_of_pi, 4)) == '4ccf5d819bcfa0bd1603dc31ab5aa649'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
