OK_FORMAT = True

test = {   'name': 'q5a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(to_percentage(0.35)) == 'e2e536cebe0aee01493dbece3a42cf40'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(twenty_percent) == '75cf3ac5e70c76583be3efb5012bd44e'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
