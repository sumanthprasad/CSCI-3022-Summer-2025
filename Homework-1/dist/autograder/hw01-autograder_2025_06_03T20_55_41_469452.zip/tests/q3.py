OK_FORMAT = True

test = {   'name': 'q3',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': ">>> assert names_q3 in ['A', 'B', 'C', 'D']\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(names_q3) == '0d61f8370cad1d412f80b84d143e1257'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
