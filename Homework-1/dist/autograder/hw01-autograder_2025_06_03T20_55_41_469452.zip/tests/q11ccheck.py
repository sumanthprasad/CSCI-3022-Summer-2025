OK_FORMAT = True

test = {   'name': 'q11ccheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q11c_answer, 6)) == 'caed457b2e3a7d5fa3ede3de63e1fe34'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
