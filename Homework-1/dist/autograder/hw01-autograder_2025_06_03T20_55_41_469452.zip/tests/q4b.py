OK_FORMAT = True

test = {   'name': 'q4b',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> assert intsqr == [x ** 2 for x in range(1, 101)]\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
