OK_FORMAT = True

test = {   'name': 'q11dcheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(q11d_answer) == '38af86134b65d0f10fe33d30dd76442e'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
