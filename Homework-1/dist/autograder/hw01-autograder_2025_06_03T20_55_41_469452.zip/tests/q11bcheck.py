OK_FORMAT = True

test = {   'name': 'q11bcheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q11b_answer, 6)) == '0f7087f36d3e157843feb7566cb4d407'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
