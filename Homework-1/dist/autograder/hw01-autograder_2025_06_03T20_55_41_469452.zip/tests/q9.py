OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(summation(1)) == 'a87ff679a2f3e71d9181a67b7542122c'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(summation(2)) == '1ff1de774005f8da13f42943881c655f'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(summation(100)) == '932348b9cc333ed91b5153c91769d66c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
