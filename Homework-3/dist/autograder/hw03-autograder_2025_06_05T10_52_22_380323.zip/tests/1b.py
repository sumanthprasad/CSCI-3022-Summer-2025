OK_FORMAT = True

test = {   'name': '1b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(offense_counts['ASSAULT/BATTERY MISD.']) == 'c45147dee729311ef5b5c3003946c48f'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(cvlegend_counts.size) == 'b6d767d2f8ed5d21a44b0e5886680cb9'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(cvlegend_counts['ASSAULT']) == '7ef605fc8dba5425d6965fbd4c8fbe1f'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
