OK_FORMAT = True

test = {   'name': 'q2d',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(mean_hour, 13.12727963525836)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(median_hour, 14)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(q1, 9)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(q3, 18)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(IQR, 9)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
