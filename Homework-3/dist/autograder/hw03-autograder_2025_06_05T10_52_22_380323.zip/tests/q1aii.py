OK_FORMAT = True

test = {   'name': 'q1aii',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(calls.shape[1]) == 'c20ad4d76fe97759aa27a0c99bff6710'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(calls.shape[0]) == '75455e062929d32a333868084286bb68'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(calls.loc[1, 'EVENT_TS']) == 'cd5252ea65ebc95fc2ae8c56fb9e3b19'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(last_event_timestamp) == '2af487344588f060428f9a266e280876'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(first_event_timestamp) == 'c0fb5f8c6c2f8e397fe28d3358c31417'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
