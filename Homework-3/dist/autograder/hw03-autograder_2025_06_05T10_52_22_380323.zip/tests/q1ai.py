OK_FORMAT = True

test = {   'name': 'q1ai',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(eventdt_type) == '9a86641cdf2fdb47f786dc955264738d'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
