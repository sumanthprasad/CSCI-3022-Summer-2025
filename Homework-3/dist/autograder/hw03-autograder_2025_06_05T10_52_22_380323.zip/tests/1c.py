OK_FORMAT = True

test = {   'name': '1c',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(calls_by_cvlegend_and_offense.size) == '34173cb38f07f89ddbebc2ac9128303f'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(calls_by_cvlegend_and_offense['WEAPONS OFFENSE', 'BRANDISHING']) == '8e296a067a37563370ded05f5a3bf3ec'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
