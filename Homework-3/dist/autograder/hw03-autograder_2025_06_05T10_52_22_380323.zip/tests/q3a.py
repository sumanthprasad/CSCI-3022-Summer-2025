OK_FORMAT = True

test = {   'name': 'q3a',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> assert 'Lat' in calls.columns and 'Lon' in calls.columns\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(str(calls.loc[1137, 'Lat'])) == 'bd2603e4d82b4b7a0da7931835b1b997'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(str(calls.loc[689]['Lon'])) == 'd00e4be72215f07e9c0dceff1bf35e52'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
