OK_FORMAT = True

test = {   'name': 'q3b',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> assert missing_lat_lon.shape == (20, 16)\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert missing_lat_lon['BLKADDR'].isna().sum() == len(missing_lat_lon)\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
