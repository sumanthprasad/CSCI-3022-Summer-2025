OK_FORMAT = True

test = {   'name': 'q1d',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(answer1, list)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert all([isinstance(elt, str) for elt in answer1])\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(len(answer1)) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert all([elt in calls['OFFENSE'].values for elt in answer1])\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> check = list(set([a.strip().upper() for a in answer1]))\n>>> check.sort()\n>>> assert get_hash(check) == 'bbf876a0c4e89351771267d0b1376ceb'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
