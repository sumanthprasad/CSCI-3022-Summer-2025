OK_FORMAT = True

test = {   'name': 'q3e',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(count_by_date.loc['2021-06-08', 'CALL_TOT']) == 'd3d9446802a44259755d38e6d163e820'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(count_by_date.loc['2021-06-10', 'CALL_TOT']) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(count_by_date.loc['2021-04-22', 'CALL_TOT']) == '8e296a067a37563370ded05f5a3bf3ec'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
