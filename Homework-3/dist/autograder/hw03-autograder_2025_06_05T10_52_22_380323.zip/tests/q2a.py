OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert set(calls['DayType']) == set(['Weekday', 'Weekend'])\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(calls.loc[3, 'DayType']) == '4718c6d81f3a33c62ac04908cc7d9b71'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(calls.loc[12, 'DayType']) == '61b2ba12e6207f265362fec55427b784'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
