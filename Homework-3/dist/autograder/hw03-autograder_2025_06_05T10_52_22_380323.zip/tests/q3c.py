OK_FORMAT = True

test = {   'name': 'q3c',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(len(missing_by_crime)) == 'c9f0f895fb98ab9159f51fd0297e236d'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(round(missing_by_crime[0], 4)) == 'af1a898ab9e9d3c3a3ab784859ed1b08'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(round(missing_by_crime[5], 4)) == '343b59949ee6c5497e703840fc2b537c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
