OK_FORMAT = True

test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert isinstance(calls.loc[72, 'Hour'], (int, np.integer))\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert calls['Hour'][72] == 18\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
