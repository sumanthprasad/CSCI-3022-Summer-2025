OK_FORMAT = True

test = {   'name': 'q4bii',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert three_kind(['H3', 'S3', 'D3', 'H4', 'C5']) == True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert three_kind(['C4', 'D4', 'S4', 'H4', 'H2']) == False\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert three_kind(['SA', 'S4', 'S4', 'H5', 'H10']) == False\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert three_kind(['SA', 'DA', 'HA', 'C5', 'H5']) == False\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert three_kind(['S3', 'D3', 'H4', 'C4', 'H5']) == False\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert three_kind(['S10', 'D10', 'H10', 'CQ', 'HA']) == True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
