OK_FORMAT = True

test = {   'name': 'q4acheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q4a_answer, 4)) == 'ace990a0524b7549fea9afe4a158c01c'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
