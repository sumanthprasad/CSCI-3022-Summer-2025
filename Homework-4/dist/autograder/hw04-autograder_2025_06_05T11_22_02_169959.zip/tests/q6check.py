OK_FORMAT = True

test = {   'name': 'q6check',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q6a_answer, 5)) == '439546d788c53a6c0c1c5194027e5d36'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
