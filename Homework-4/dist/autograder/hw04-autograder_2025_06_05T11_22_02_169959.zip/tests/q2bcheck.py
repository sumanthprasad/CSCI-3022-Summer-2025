OK_FORMAT = True

test = {   'name': 'q2bcheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q2b_answer, 4)) == 'f452927b0b2a755192117d956a8d47f6'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
