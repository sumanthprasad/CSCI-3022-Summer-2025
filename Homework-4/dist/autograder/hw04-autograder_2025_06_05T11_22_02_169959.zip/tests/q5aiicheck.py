OK_FORMAT = True

test = {   'name': 'q5aiicheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q5aii_answer, 4)) == 'd80cd8a9bc59ca0c1f479e4eca3c64be'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
