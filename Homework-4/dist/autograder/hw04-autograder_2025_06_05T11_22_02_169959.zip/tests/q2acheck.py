OK_FORMAT = True

test = {   'name': 'q2acheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q2a_answer, 4)) == '3d522deaf85577451c01974654b36ad3'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
