OK_FORMAT = True

test = {   'name': 'q1c',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(at_least_one_green, 4)) == 'bdfd2bbc94051b89092784727dadb9c9'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
