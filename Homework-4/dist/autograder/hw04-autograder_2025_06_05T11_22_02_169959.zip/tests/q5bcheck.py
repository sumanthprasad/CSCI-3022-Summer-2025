OK_FORMAT = True

test = {   'name': 'q5bcheck',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(round(q5bi_answer, 4)) == '790abc5c38e7c740420b03c24fabb05b'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(round(q5bii_answer, 4)) == 'b4b8f49579f52a53c6963b8f8f685a29'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
