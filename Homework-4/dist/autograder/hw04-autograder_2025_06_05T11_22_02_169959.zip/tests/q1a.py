OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(first_three_black, 4)) == '271991f15c06e3dd9aa7a0d196ff5b19'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
