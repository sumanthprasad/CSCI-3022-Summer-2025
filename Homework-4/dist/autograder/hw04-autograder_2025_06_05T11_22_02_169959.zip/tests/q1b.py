OK_FORMAT = True

test = {   'name': 'q1b',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(no_green, 4)) == '157efb8545e3fd05e47afd97f4816d17'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
