OK_FORMAT = True

test = {   'name': 'q4bi',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(len(cards)) == '9a1158154dfa42caddbd0694a4e9bdc8'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(sorted(set(cards))) == '83dfc5b12f2790365c2b2ba676e90de0'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
