OK_FORMAT = True

test = {   'name': 'q7bcheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q7b_answer, 4)) == 'c29ea1fe96eb4921715b8ceae933a374'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
