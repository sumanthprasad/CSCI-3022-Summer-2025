OK_FORMAT = True

test = {   'name': 'q7acheck',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(q7a_answer, 6)) == 'cb96698ec25a583b061cc9b57a4d3e36'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
