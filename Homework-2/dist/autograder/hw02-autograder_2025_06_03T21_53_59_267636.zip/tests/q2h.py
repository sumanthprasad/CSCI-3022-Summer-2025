OK_FORMAT = True

test = {   'name': 'q2h',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(payroll_df_merged.shape[0]) == '6f4922f45568161a8cdf4ad2299f6d23'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df_merged.shape[1]) == 'e4da3b7fbbce2345d7772b0674a318d5'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df_merged.loc[('BOS', 2003), 'payroll']) == 'f2e873cf5a228e1d9530f60820b7b6fc'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df_merged.loc[('OAK', 1999), 'winFrac']) == '676813538852c7111802c95f5ca99e41'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
