OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(salaries_df.iloc[0, 4]) == '0084883cb7b090fa951c16338faa4b06'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salaries_df.size) == '4b094151d0f7e3e2941d4dde33c48e64'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
