OK_FORMAT = True

test = {   'name': 'q2c',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(unique_teams) == 'f2217062e9a397a1dca429e7d70bc6ca'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(unique_teams_salary) == '1c383cd30b7c298ab50293adfecb7b18'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(teams_startyear) == 'fb8feff253bb6c834deb61ec76baa893'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(teams_endyear) == '3a824154b16ed7dab899bf000b80eeee'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salaries_startyear) == '1f36c15d6a3d18d52e8d493bc8187cb9'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salaries_endyear) == '95192c98732387165bf8e396c0f2dad2'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
