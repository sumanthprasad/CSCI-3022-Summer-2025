OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(round(p_HHHTHT, 6)) == '8621a84afb6956533591c0832ff1ba09'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
