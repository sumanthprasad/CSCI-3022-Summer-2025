OK_FORMAT = True

test = {   'name': 'q2f',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(payroll_df.loc[('OAK', 2002), 'payroll']) == 'a42b2a27b320d77143ad7a206817b4c2'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df.shape[0]) == '6f4922f45568161a8cdf4ad2299f6d23'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df.shape[1]) == 'c4ca4238a0b923820dcc509a6f75849b'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(payroll_df.loc[('BOS', 2004), 'payroll']) == 'd02548c81c261214893c92e0c26aa601'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
