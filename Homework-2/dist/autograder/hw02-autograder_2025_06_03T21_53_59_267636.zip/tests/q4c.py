OK_FORMAT = True

test = {   'name': 'q4c',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert get_hash(p_hat) == '54fbf38cf649866815e0fefc46a1f6c7'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
