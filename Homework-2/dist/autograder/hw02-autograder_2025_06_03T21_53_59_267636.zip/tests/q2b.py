OK_FORMAT = True

test = {   'name': 'q2b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(team_rows) == '51be2fed6c55f5aa0c16ff14c140b187'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(team_col) == '642e92efb79421734881b53e1e1b18b6'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salary_rows) == '398a516d8fbfdd9158eec76b283dd9ce'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salary_col) == 'e4da3b7fbbce2345d7772b0674a318d5'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(missing_attendance) == 'd395771085aab05244a4fb8fd91bf4ee'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
