OK_FORMAT = True

test = {   'name': 'q2d',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(winFrac_OAK_98) == '3b97a72e9bc7f5c5e225aec9b0bf548c'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(teams_df_moneyball.shape[1]) == 'e4da3b7fbbce2345d7772b0674a318d5'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(teams_df_moneyball.shape[0]) == 'b137fdd1f79d56c7edf3365fea7520f2'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert get_hash(teams_df_moneyball[teams_df_moneyball['yearID'] == 2001].loc['FLO', 'W']) == 'fbd7939d674997cdb4692d34de8633c4'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(teams_df_moneyball.query('yearID==2010').loc['BOS', 'winFrac']) == '10efc2614821dcf1b1ebc941ebd6ce1f'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
