OK_FORMAT = True

test = {   'name': 'q2g',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(teams_df_moneyball.loc[('ANA', 1999), 'W']) == '7cbbc409ec990f19c78c75bd1e06f215'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(teams_df_moneyball.loc[('OAK', 2001), 'winFrac']) == 'b9c48c2d04160ef1ff72dba569292058'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
