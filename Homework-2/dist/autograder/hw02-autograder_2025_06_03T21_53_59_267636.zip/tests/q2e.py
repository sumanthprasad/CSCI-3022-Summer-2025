OK_FORMAT = True

test = {   'name': 'q2e',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(salaries_subset.shape[1]) == 'eccbc87e4b5ce2fe28308fd9f2a7baf3'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salaries_subset.shape[0]) == '63538fe6ef330c13a05a3ed7e599d5f7'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(salaries_subset.loc[11425, 'salary']) == 'c9077732a294f90a75acea3ce5f2a4e8'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
