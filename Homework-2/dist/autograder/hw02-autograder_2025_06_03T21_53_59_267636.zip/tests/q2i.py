OK_FORMAT = True

test = {   'name': 'q2i',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert get_hash(nya_payroll_02) == 'c181907c1a7dc2fd99e65ea1f42e2978'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert get_hash(nya_winfrac_02) == '100dd920921e3c509b9afd9dff04f149'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
