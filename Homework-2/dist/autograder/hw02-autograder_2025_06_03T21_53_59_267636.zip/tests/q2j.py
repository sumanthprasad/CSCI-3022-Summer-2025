OK_FORMAT = True

test = {   'name': 'q2j',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(round(payroll_df_merged.loc[('OAK', 2003), 'efficiency'], 2)) == '4c54b0a8f1705002aef1b34d14cff762'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert get_hash(round(payroll_df_merged.loc[('NYA', 1999), 'efficiency'], 2)) == '670eb53716271fd8f56193dd794b001f'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
